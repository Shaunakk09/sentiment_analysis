from django.contrib import admin
from home.models import Review
# Register your models here.
admin.site.register(Review)

